<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand lobster" href="/" >alphasquare</a>
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">

      
    </ul><p class="navbar-text pull-right" ><i class="glyphicon glyphicon-log_in"></i> 
  <a href="login.php" class="no-decor-link open-sans " style="text-decoration:none;color:white;"> Have an account? Sign in &raquo;</a>
  </p>
  </div><!-- /.navbar-collapse -->
</nav>