
<div class="container">    

    <hr>
    <div class="row-fluid">
        <div class="span12">
            <div class="span8">

            </div>
            <div class="span4">
                <p class="muted pull-right">&copy;  2013-2014 Alphasquare </p>
            </div>
        </div>
    </div>
</div>