<?php
include_once('../universal.php');
$users = show_users($_SESSION['userid']);
if (count($users)){
	$myusers = array();
	$myusers = array_keys($users);
}else{
	$myusers = array();
}
$myusers[] = $_SESSION['userid'];
$posts = get_posts($myusers,0);
if (count($posts)){
?>
<?php
foreach ($posts as $key => $list){
?>
<div style="width:100%;display:flex;"> 
<img class="img-circle" src="<?php profilePictureID($list['userid']) ?>" style="height:53px;width:53px; border:1px solid white;">&nbsp;&nbsp;&nbsp;
<article class="box" style="word-wrap:break-word;font-size:17px;flex:1 0 0;padding-bottom:10px;"><?php echo showBBcodes(htmlentities($list['content'])); ?><hr style="margin-bottom:5px;"><small><a class="btn btn-success btn-xs slab" href="resources/vote.php?id=<?php echo $list['id']; ?>&type=1"><span class="glyphicon glyphicon-thumbs-up "></span> <?php votes($list['id'], 1); ?> </a>&nbsp; <a class="btn btn-success btn-xs slab" href="resources/vote.php?id=<?php echo $list['id']; ?>&type=0"><span class="glyphicon glyphicon-thumbs-down"></span> <?php votes($list['id'], 0); ?></a>&nbsp;<a href="#" class="btn btn-xs btn-info"><span class="glyphicon glyphicon-comment"></span> Discussion</a></small><small class="pull-right" style="color:grey;font-size:15px;">3 minutes ago</small></article></div>
<br><br>
<?php 
}
?>
</table>
<?php
} else{
?>
<p><b>You haven't posted anything yet!</b></p>
<?php
}
?>