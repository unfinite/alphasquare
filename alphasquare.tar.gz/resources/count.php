<?php
include '../universal.php';
alert_count();
?>