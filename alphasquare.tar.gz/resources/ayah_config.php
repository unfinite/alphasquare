<?php
// Edit the two lines below to use the keys for your site.
// (Note: you can find your keys at http://portal.areyouahuman.com/dashboard)
define( 'AYAH_PUBLISHER_KEY', '4d75ff76c5467bcf0d6bc00e3202b970b3fcbfa7');
define( 'AYAH_SCORING_KEY', 'f880aa9e789a0d5c8d2a270bf92668943784a12a');


// Set defaults for values needed by the ayah.php file.
// (Note: you do not need to change these.)
define( 'AYAH_WEB_SERVICE_HOST', 'ws.areyouahuman.com');
define( 'AYAH_TIMEOUT', 0);
define( 'AYAH_DEBUG_MODE', FALSE);
define( 'AYAH_USE_CURL', TRUE);