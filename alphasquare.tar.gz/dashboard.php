  <?php
include('universal.php');

blockGuest();


?>

<!DOCTYPE html>
<html>
    <head><link href='//cdnjs.cloudflare.com/ajax/libs/animate.css/3.0.0/animate.min.css' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Roboto:100,300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Roboto+Slab:300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <title>Debates - Alphasquare</title>
  
    <meta name="viewport" content="width=device-width, initial-scale=1">
<script src="js/growl.js"></script>    <!-- Bootstrap -->
 <link href="themes/bootstrap.css" rel="stylesheet">
<!-- Start of Woopra Code -->
<style>
.post {
	height:50px;width:100%;font-family:'Roboto Slab';font-size:20px;
padding-left:10px;padding-right:10px;border:1px solid #bdc3c7;border-radius:5px;
}
.box {
	width:100%;font-family:'Roboto Slab';padding-top:20px;padding-bottom:20px;
padding-left:10px;padding-right:10px;border:1px solid #bdc3c7;border-radius:4px;background-color: white;
}
.slab {
	font-family: Roboto Slab;
}
</style>

<!-- End of Woopra Code -->
    </head>

    <body style="background-color:rgb(236, 240, 241);">
    <?php 
include('assets/navbar-logged.php');
?>
<div class="container">
<br><br><br><br>
<div class="row">
  <div class="col-xs-12 col-md-8">
  
<form method='post' class="form-inline" action='add.php'>

<input name='body' class="post" placeholder="Whatcha debatin' on, <?php getUsername(); ?>?">
</input>
</form>

<br>



<div id="posts"> 
<?php if (isset($_SESSION['message'])){echo htmlentities($_SESSION['message']);unset($_SESSION['message']);};?>

</div></div>
  <div class="col-xs-6 col-md-4">
  <div class="panel panel-default">
  <div class="panel-body">
    <ul class="nav nav-pills nav-stacked slab">

  <li class="active">
    <a href="#">
      
      Dashboard
    </a>
    
  </li>
  <li>
   <a onclick="markread()"   data-toggle="modal"
   data-target="#alerts" href="#">
 <span class="badge badge-danger pull-right" id="alerts2"></span>
      Alerts
    </a>
    </li>
  <li>
  <a href="#">
      People
    </a>
    </li>
    <li>
    <a href="#">
      Me
    </a>
    </li>
</ul>

  </div>
</div>
<br>
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title slab">People</h3>
  </div>
  <div class="panel-body">
    <?php

$users = show_users($_SESSION['userid']);

if (count($users)){
?>

<?php
foreach ($users as $key => $value){
?> <img src="<?php profilePicture($value) ?>" class="img-circle" style="width:40px;height:40px;">
<?php
}
?>
<?php
}else{
?>
<b>You're not following anyone yet. Here are some reccomendations: </b>
<?php
}
?>
  </div>
</div>
</div>
</div>
</div>
<script src="js/jquery.js"></script>
<script>
function quasar(){
    $.post('resources/posts.php',function(data){
        $("#posts").html(data);
    });

    $.post('resources/count.php',function(data){
    $("#alerts2").html(data);
    });

    $.post('resources/alerts.php',function(data){
    $("#alert-modal").html(data);
    });

    $.post('resources/notifications.php',function(data){
      alert("LOG: Notifications is getting called.");
    });

    setTimeout("quasar();",10000);
}

window.onload = quasar();


function markread() {
    $.get("resources/mark.php");
}

 </script>

    <script src="js/bootstrap.min.js"></script> 
 <div class="modal fade" id="alerts" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content" >
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title slab">Alerts</h4>
        </div>
        <div class="modal-body" id="alert-modal" style="max-height: 420px;
    overflow-y: auto;">
    
        </div>
        <div class="modal-footer">
          <button type="button" data-dismiss="modal" class="btn btn-primary">Okay, I'm done.</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
    </body>
</html>
